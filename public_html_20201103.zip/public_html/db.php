<?php
$serv = "localhost";
$unm = "id15024191_root";
$pwd = "Ars!@#123database";
$db_name = "id15024191_absensi";
$conn = new mysqli($serv, $unm, $pwd, $db_name);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
